class Shark < Fish

  def initialize
    super(15,50)
  end

end