class GiantSalmon < Fish

  def initialize 
    super(4,30)
  end

end