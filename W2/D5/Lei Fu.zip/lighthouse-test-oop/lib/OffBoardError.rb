class OffBoardError < StandardError

end